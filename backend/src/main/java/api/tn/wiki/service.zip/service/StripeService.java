package api.tn.wiki.service;

import api.tn.wiki.entity.Order;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

@Service
public class StripeService {

    @Value("${stripe.api.key}")
    private String secretKey;

    @Value("${app.frontend.url}")
    private String frontendUrl;

    @Value("${app.currency.exchange-rate.tnd-to-eur}")
    private double exchangeRate;

    @PostConstruct
    public void init() {
        Stripe.apiKey = secretKey;
    }

    public String createCheckoutSession(Order order) throws Exception {
        SessionCreateParams params = SessionCreateParams.builder()
                .addPaymentMethodType(SessionCreateParams.PaymentMethodType.CARD)
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl(frontendUrl + "/order-success?orderId=" + order.getId())
                .setCancelUrl(frontendUrl + "/checkout?order_cancel=true")
                .addLineItem(
                        SessionCreateParams.LineItem.builder()
                                .setQuantity(1L)
                                .setPriceData(
                                        SessionCreateParams.LineItem.PriceData.builder()
                                                .setCurrency("eur")
                                                .setUnitAmount((long) (order.getTotalAmount() * exchangeRate * 100)) // Convert to EUR and then to cents
                                                .setProductData(
                                                        SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                .setName("Commande Wiki.tn #" + order.getId())
                                                                .build()
                                                )
                                                .build()
                                )
                                .build()
                )
                .setClientReferenceId(order.getId().toString())
                .build();

        Session session = Session.create(params);
        return session.getUrl();
    }
}
