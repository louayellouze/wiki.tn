package api.tn.wiki.service;

import api.tn.wiki.entity.Coupon;
import api.tn.wiki.repository.CouponRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CouponService {

    private final CouponRepository couponRepository;
    private final org.springframework.mail.javamail.JavaMailSender mailSender;

    public CouponService(CouponRepository couponRepository, org.springframework.mail.javamail.JavaMailSender mailSender) {
        this.couponRepository = couponRepository;
        this.mailSender = mailSender;
    }

    @Transactional(readOnly = true)
    public Coupon getRandomActiveCoupon() {
        List<Coupon> activeCoupons = couponRepository.findAll().stream()
                .filter(c -> c.getIsActive() && (c.getExpiryDate() == null || c.getExpiryDate().isAfter(LocalDateTime.now())))
                .collect(java.util.stream.Collectors.toList());
        
        if (activeCoupons.isEmpty()) {
            return null;
        }
        
        return activeCoupons.get(new java.util.Random().nextInt(activeCoupons.size()));
    }

    public void sendCouponWinEmail(String email, Coupon coupon) {
        try {
            org.springframework.mail.SimpleMailMessage message = new org.springframework.mail.SimpleMailMessage();
            message.setFrom("louayellouze01@gmail.com");
            message.setTo(email);
            message.setSubject("Félicitations ! Vous avez gagné un coupon Wiki");
            
            String expiry = coupon.getExpiryDate() != null 
                ? coupon.getExpiryDate().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) 
                : "Sans expiration";

            message.setText("Félicitations !\n\n" +
                            "Vous venez de gagner un coupon de réduction sur Wiki.tn via notre Roue de la Fortune.\n\n" +
                            "VOTRE CODE : " + coupon.getCode() + "\n" +
                            "VALEUR : " + coupon.getDiscountValue() + (coupon.getDiscountType() == Coupon.DiscountType.PERCENT ? "%" : " DT") + "\n" +
                            "VALABLE JUSQU'AU : " + expiry + "\n\n" +
                            "Utilisez-le lors de votre prochaine commande sur Wiki.tn !\n\n" +
                            "Cordialement,\n" +
                            "L'équipe Wiki");
            
            mailSender.send(message);
        } catch (Exception e) {
            System.err.println("Échec de l'envoi de l'email coupon : " + e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<Coupon> getAllCoupons() {
        return couponRepository.findAll();
    }

    @Transactional
    public Coupon createCoupon(Coupon coupon) {
        return couponRepository.save(coupon);
    }

    @Transactional
    public Coupon updateCoupon(Long id, Coupon details) {
        Coupon coupon = couponRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Coupon not found"));
        coupon.setCode(details.getCode());
        coupon.setDiscountType(details.getDiscountType());
        coupon.setDiscountValue(details.getDiscountValue());
        coupon.setMinOrderAmount(details.getMinOrderAmount());
        coupon.setExpiryDate(details.getExpiryDate());
        coupon.setIsActive(details.getIsActive());
        return couponRepository.save(coupon);
    }

    @Transactional
    public void deleteCoupon(Long id) {
        couponRepository.deleteById(id);
    }

    public Coupon validateCoupon(String code, Double orderAmount) {
        Coupon coupon = couponRepository.findByCode(code)
                .orElseThrow(() -> new RuntimeException("Coupon invalide"));

        if (!coupon.getIsActive()) {
            throw new RuntimeException("Coupon inactif");
        }

        if (coupon.getExpiryDate() != null && coupon.getExpiryDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Coupon expiré");
        }

        if (orderAmount < coupon.getMinOrderAmount()) {
            throw new RuntimeException("Montant minimum de commande non atteint (" + coupon.getMinOrderAmount() + " DT)");
        }

        return coupon;
    }
}
