package api.tn.wiki.service;

import api.tn.wiki.entity.Order;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendOrderStatusEmail(Order order) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("louayellouze01@gmail.com");
            message.setTo(order.getUser().getEmail());
            
            String statusLabel = translateStatus(order.getStatus());
            message.setSubject("Mise à jour de votre commande Wiki #" + order.getId());
            
            StringBuilder content = new StringBuilder();
            content.append("Bonjour ").append(order.getUser().getFirstName()).append(",\n\n");
            content.append("Le statut de votre commande #").append(order.getId()).append(" a été mis à jour.\n\n");
            content.append("NOUVEAU STATUT : ").append(statusLabel).append("\n\n");
            
            if (order.getStatus().name().equals("SHIPPED")) {
                content.append("Bonne nouvelle ! Votre colis est en route et vous sera livré très prochainement.\n\n");
            } else if (order.getStatus().name().equals("DELIVERED")) {
                content.append("Votre commande a été livrée avec succès. Merci de votre confiance !\n\n");
            } else if (order.getStatus().name().equals("CANCELLED")) {
                content.append("Nous vous informons que votre commande a été annulée. Si vous n'êtes pas à l'origine de cette demande, veuillez nous contacter.\n\n");
            }
            
            content.append("Vous pouvez suivre l'état de votre commande à tout moment sur notre site via votre numéro de commande et votre email.\n\n");
            content.append("Cordialement,\n");
            content.append("L'équipe Wiki.tn");
            
            message.setText(content.toString());
            mailSender.send(message);
        } catch (Exception e) {
            System.err.println("Échec de l'envoi de l'email de commande : " + e.getMessage());
        }
    }

    public void sendOrderConfirmationEmail(Order order) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("louayellouze01@gmail.com");
            message.setTo(order.getUser().getEmail());
            message.setSubject("Confirmation de votre commande Wiki #" + order.getId());

            StringBuilder content = new StringBuilder();
            content.append("Bonjour ").append(order.getUser().getFirstName()).append(",\n\n");
            content.append("Merci pour votre commande chez Wiki.tn !\n\n");
            content.append("Détails de la commande #").append(order.getId()).append(" :\n");
            content.append("------------------------------------------\n");
            
            order.getItems().forEach(item -> {
                content.append("- ").append(item.getProduct().getTitle())
                       .append(" (x").append(item.getQuantity()).append(") : ")
                       .append(String.format("%.3f", item.getPrice() * item.getQuantity()))
                       .append(" TND\n");
            });

            content.append("------------------------------------------\n");
            content.append("TOTAL : ").append(String.format("%.3f", order.getTotalAmount())).append(" TND\n");
            content.append("Mode de paiement : ").append(order.getPaymentMethod().name()).append("\n");
            content.append("Adresse : ").append(order.getAddress()).append("\n\n");

            if (order.getPaymentMethod().name().equals("STRIPE")) {
                content.append("Votre paiement est en cours de traitement. Vous recevrez une confirmation dès que le paiement sera validé.\n\n");
            } else {
                content.append("Votre commande est en attente de validation par notre équipe.\n\n");
            }

            content.append("Merci de votre confiance !\n\n");
            content.append("Cordialement,\n");
            content.append("L'équipe Wiki.tn");

            message.setText(content.toString());
            mailSender.send(message);
            System.out.println("✅ Email de confirmation envoyé pour la commande #" + order.getId());
        } catch (Exception e) {
            System.err.println("❌ Échec de l'envoi de l'email de confirmation : " + e.getMessage());
        }
    }

    public void sendWelcomeEmail(api.tn.wiki.entity.User user) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("louayellouze01@gmail.com");
            message.setTo(user.getEmail());
            message.setSubject("Bienvenue chez Wiki.tn !");
            
            StringBuilder content = new StringBuilder();
            content.append("Bonjour ").append(user.getFirstName()).append(",\n\n");
            content.append("C'est un plaisir de vous compter parmi nos nouveaux clients !\n\n");
            content.append("Chez Wiki, nous nous engageons à vous offrir le meilleur de la technologie au meilleur prix. ");
            content.append("Votre compte a été créé avec succès et vous pouvez désormais profiter de tous nos services.\n\n");
            
            content.append("CE QUE VOUS POUVEZ FAIRE MAINTENANT :\n");
            content.append("- Explorer notre large catalogue de produits informatiques.\n");
            content.append("- Suivre vos commandes en temps réel.\n");
            content.append("- Recevoir nos offres exclusives et ventes flash.\n\n");
            
            content.append("Nous sommes à votre disposition pour toute question.\n\n");
            content.append("Bienvenue dans la communauté Wiki !\n\n");
            content.append("Cordialement,\n");
            content.append("L'équipe Wiki.tn");
            
            message.setText(content.toString());
            mailSender.send(message);
            System.out.println("✅ Email de bienvenue envoyé à : " + user.getEmail());
        } catch (Exception e) {
            System.err.println("❌ Échec de l'envoi de l'email de bienvenue : " + e.getMessage());
        }
    }

    public void sendStockNotificationEmail(api.tn.wiki.entity.User user, api.tn.wiki.entity.Product product) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("louayellouze01@gmail.com");
            message.setTo(user.getEmail());
            message.setSubject("Bonne nouvelle ! " + product.getTitle() + " est de retour en stock");

            StringBuilder content = new StringBuilder();
            content.append("Bonjour ").append(user.getFirstName()).append(",\n\n");
            content.append("Vous nous aviez demandé de vous prévenir quand le produit suivant serait de nouveau disponible :\n\n");
            content.append("PRODUIT : ").append(product.getTitle()).append("\n");
            content.append("PRIX : ").append(String.format("%.3f", product.getDiscountPrice() != null ? product.getDiscountPrice() : product.getRegularPrice())).append(" TND\n\n");
            
            content.append("C'est chose faite ! Le produit est maintenant disponible sur notre site.\n\n");
            content.append("Ne tardez pas, les stocks sont limités !\n\n");
            
            content.append("Lien vers le produit : http://localhost:3000/products/").append(product.getSlug()).append("\n\n");

            content.append("Cordialement,\n");
            content.append("L'équipe Wiki.tn");

            message.setText(content.toString());
            mailSender.send(message);
            System.out.println("✅ Email de notification de stock envoyé à : " + user.getEmail() + " pour le produit : " + product.getTitle());
        } catch (Exception e) {
            System.err.println("❌ Échec de l'envoi de l'email de notification de stock : " + e.getMessage());
        }
    }

    private String translateStatus(api.tn.wiki.entity.OrderStatus status) {
        return switch (status) {
            case PENDING -> "En attente";
            case CONFIRMED -> "Confirmée";
            case SHIPPED -> "Expédiée";
            case DELIVERED -> "Livrée";
            case CANCELLED -> "Annulée";
            case IN_DELIVERY_ARAMEX -> "En cours de livraison (Aramex)";
            case AWAITING_PAYMENT -> "En attente de paiement (Stripe)";
            default -> status.name();
        };
    }
}
