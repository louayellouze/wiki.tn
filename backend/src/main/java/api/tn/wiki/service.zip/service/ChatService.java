package api.tn.wiki.service;

import api.tn.wiki.dto.chat.ChatRequest;
import api.tn.wiki.dto.chat.ChatResponse;
import api.tn.wiki.dto.response.ProductResponse;
import api.tn.wiki.dto.response.ProductMinResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ChatService {

    private static final Logger logger = LoggerFactory.getLogger(ChatService.class);

    @Value("${openai.api.key}")
    private String apiKey;

    @Value("${openai.model:gpt-4o-mini}")
    private String model;

    @Value("${openai.api.url:https://api.openai.com/v1/chat/completions}")
    private String apiUrl;

    private final ProductService productService;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public ChatService(ProductService productService, ObjectMapper objectMapper) {
        this.productService = productService;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newHttpClient();
    }

    public ChatResponse processChat(ChatRequest request) throws Exception {
        if ("YOUR_OPENAI_API_KEY_HERE".equals(apiKey) || apiKey.isEmpty()) {
            return new ChatResponse("Désolé, la clé API OpenAI n'est pas configurée. Veuillez configurer 'openai.api.key' dans le backend.");
        }


        // Preparation of messages for OpenAI
        ArrayNode messagesArray = objectMapper.createArrayNode();
        
        // System prompt
        ObjectNode systemMsg = objectMapper.createObjectNode();
        systemMsg.put("role", "system");
        systemMsg.put("content", "Tu es Wiki Bot, un expert de la vente et conseiller technique pour la boutique en ligne Wiki (Tunisie). " +
                "Ton rôle est d'aider les clients à trouver les meilleurs produits (PC, smartphones, accessoires, etc.). " +
                "Sois enthousiaste, vendeur, professionnel et de bon conseil. " +
                "Utilise systématiquement l'outil 'search_products' pour chercher des produits dans notre catalogue au lieu d'inventer des produits. " +
                "Une fois les résultats de la recherche obtenus, argumente sur les produits trouvés en citant leurs prix exacts (en DT) et pourquoi ils correspondent au besoin du client. " +
                "Fais des phrases courtes, claires et percutantes. Réponds toujours en français.");
        messagesArray.add(systemMsg);

        // History
        for (ChatRequest.ChatMessage msg : request.getMessages()) {
            ObjectNode m = objectMapper.createObjectNode();
            m.put("role", msg.getRole());
            m.put("content", msg.getContent());
            messagesArray.add(m);
        }

        // Define tools (Function Calling)
        ArrayNode tools = objectMapper.createArrayNode();
        ObjectNode tool = objectMapper.createObjectNode();
        tool.put("type", "function");
        ObjectNode function = objectMapper.createObjectNode();
        function.put("name", "search_products");
        function.put("description", "Recherche des produits dans le catalogue Wiki par nom, marque ou caractéristiques.");
        ObjectNode parameters = objectMapper.createObjectNode();
        parameters.put("type", "object");
        ObjectNode properties = objectMapper.createObjectNode();
        ObjectNode queryProp = objectMapper.createObjectNode();
        queryProp.put("type", "string");
        queryProp.put("description", "Le terme de recherche (ex: 'PC gamer asus', 'iPhone 15', 'souris logitech')");
        properties.set("query", queryProp);
        parameters.set("properties", properties);
        ArrayNode required = objectMapper.createArrayNode();
        required.add("query");
        parameters.set("required", required);
        function.set("parameters", parameters);
        tool.set("function", function);
        tools.add(tool);

        // Build Payload
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("model", model);
        payload.set("messages", messagesArray);
        // Réactivé car le modèle dynamiquement sélectionné par OpenRouter supporte les tools
        payload.set("tools", tools);
        payload.put("tool_choice", "auto");
        logger.info("Calling AI API at: {} with model: {}", apiUrl, model);

        // API Call
        HttpRequest apiRequest = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl.trim()))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .header("HTTP-Referer", "http://localhost:3000")
                .header("X-Title", "Wiki Bot")
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(payload)))
                .build();

        HttpResponse<String> response = httpClient.send(apiRequest, HttpResponse.BodyHandlers.ofString());
        
        if (response.statusCode() != 200) {
            logger.error("OpenAI API error: {} - {}", response.statusCode(), response.body());
            return new ChatResponse("Erreur lors de la communication avec l'IA. Code: " + response.statusCode());
        }


        JsonNode responseNode = objectMapper.readTree(response.body());
        JsonNode choice = responseNode.get("choices").get(0);
        JsonNode messageNode = choice.get("message");
        
        String assistantContent = messageNode.has("content") && !messageNode.get("content").isNull() ? messageNode.get("content").asText() : "";
        List<ChatResponse.ProductRecommendation> recommendations = new ArrayList<>();

        // Handle tool calls with a second API call
        if (messageNode.has("tool_calls")) {
            // Append the assistant's message with tool_calls to the conversation
            ObjectNode assistantMsg = objectMapper.createObjectNode();
            assistantMsg.put("role", "assistant");
            if (messageNode.has("content") && !messageNode.get("content").isNull()) {
                assistantMsg.put("content", messageNode.get("content").asText());
            } else {
                assistantMsg.putNull("content");
            }
            assistantMsg.set("tool_calls", messageNode.get("tool_calls"));
            messagesArray.add(assistantMsg);

            boolean toolExecuted = false;

            for (JsonNode toolCall : messageNode.get("tool_calls")) {
                if (toolCall.has("type") && "function".equals(toolCall.get("type").asText())) {
                    String toolCallId = toolCall.has("id") ? toolCall.get("id").asText() : "unknown";
                    JsonNode func = toolCall.get("function");
                    if (func != null && func.has("name") && "search_products".equals(func.get("name").asText())) {
                        String query = "";
                        ArrayNode productsJson = objectMapper.createArrayNode();
                        try {
                            if (func.has("arguments")) {
                                JsonNode args = objectMapper.readTree(func.get("arguments").asText());
                                if (args != null && args.has("query")) {
                                    query = args.get("query").asText();
                                }
                            }
                            
                            logger.info("WikiBot is searching for: '{}'", query);
                            if (!query.trim().isEmpty()) {
                                List<ProductMinResponse> products = productService.searchProducts(query, null, null, null);
                                
                                if (products != null) {
                                    for (ProductMinResponse p : products.stream().limit(5).collect(Collectors.toList())) {
                                        // Extract to recommendations for UI
                                        recommendations.add(new ChatResponse.ProductRecommendation(
                                                p.getId(),
                                                p.getTitle(),
                                                p.getSlug(),
                                                p.getDiscountPrice() != null && p.getDiscountPrice() > 0 ? p.getDiscountPrice() : p.getRegularPrice(),
                                                p.getImageUrl()
                                        ));
                                        
                                        // Extract to JSON for AI
                                        ObjectNode pObj = objectMapper.createObjectNode();
                                        pObj.put("title", p.getTitle());
                                        pObj.put("price", p.getDiscountPrice() != null && p.getDiscountPrice() > 0 ? p.getDiscountPrice() : p.getRegularPrice());
                                        productsJson.add(pObj);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            logger.error("Error executing search_products tool: {}", e.getMessage(), e);
                        }

                        // Add tool response to messages
                        ObjectNode toolMsg = objectMapper.createObjectNode();
                        toolMsg.put("role", "tool");
                        toolMsg.put("tool_call_id", toolCallId);
                        
                        if (productsJson.isEmpty()) {
                            toolMsg.put("content", "Aucun produit trouvé pour cette recherche.");
                        } else {
                            toolMsg.put("content", productsJson.toString());
                        }
                        messagesArray.add(toolMsg);
                        toolExecuted = true;
                    }
                }
            }
            
            // Second API Call if a tool was executed
            if (toolExecuted) {
                ObjectNode payload2 = objectMapper.createObjectNode();
                payload2.put("model", model);
                payload2.set("messages", messagesArray);
                
                logger.info("Calling AI API (Second Pass) at: {}", apiUrl);
                
                HttpRequest apiRequest2 = HttpRequest.newBuilder()
                        .uri(URI.create(apiUrl.trim()))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + apiKey)
                        .header("HTTP-Referer", "http://localhost:3000")
                        .header("X-Title", "Wiki Bot")
                        .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(payload2)))
                        .build();

                HttpResponse<String> response2 = httpClient.send(apiRequest2, HttpResponse.BodyHandlers.ofString());
                
                if (response2.statusCode() == 200) {
                    JsonNode responseNode2 = objectMapper.readTree(response2.body());
                    JsonNode choice2 = responseNode2.get("choices").get(0);
                    JsonNode messageNode2 = choice2.get("message");
                    assistantContent = messageNode2.has("content") && !messageNode2.get("content").isNull() 
                            ? messageNode2.get("content").asText() 
                            : "";
                } else {
                    logger.error("OpenAI API error on second pass: {} - {}", response2.statusCode(), response2.body());
                    if (assistantContent == null || assistantContent.isEmpty()) {
                        assistantContent = "Voici les meilleurs choix que j'ai pu trouver pour toi !";
                    }
                }
            }
        }

        return new ChatResponse(assistantContent, recommendations);

    }
}
