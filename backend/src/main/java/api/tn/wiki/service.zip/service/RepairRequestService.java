package api.tn.wiki.service;

import api.tn.wiki.entity.RepairRequest;
import api.tn.wiki.repository.RepairRequestRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RepairRequestService {

    private final RepairRequestRepository repository;

    public RepairRequestService(RepairRequestRepository repository) {
        this.repository = repository;
    }

    public List<RepairRequest> getAllRequests() {
        return repository.findAllByOrderByCreatedAtDesc();
    }

    public Page<RepairRequest> searchRequests(String query, String status, Pageable pageable) {
        Specification<RepairRequest> spec = (root, criteriaQuery, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (status != null && !status.isEmpty()) {
                predicates.add(cb.equal(root.get("status"), status));
            }

            if (query != null && !query.isEmpty()) {
                String likeQuery = "%" + query.toLowerCase() + "%";
                predicates.add(cb.or(
                    cb.like(cb.lower(root.get("firstName")), likeQuery),
                    cb.like(cb.lower(root.get("lastName")), likeQuery),
                    cb.like(cb.lower(root.get("email")), likeQuery),
                    cb.like(cb.lower(root.get("phone")), likeQuery),
                    cb.like(cb.lower(root.get("deviceType")), likeQuery),
                    cb.like(cb.lower(root.get("brand")), likeQuery),
                    cb.like(cb.lower(root.get("model")), likeQuery)
                ));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        return repository.findAll(spec, pageable);
    }

    public List<RepairRequest> getRequestsByStatus(String status) {
        return repository.findByStatusOrderByCreatedAtDesc(status);
    }

    public RepairRequest saveRequest(RepairRequest request) {
        return repository.save(request);
    }

    public Optional<RepairRequest> getRequestById(Long id) {
        return repository.findById(id);
    }

    public void deleteRequest(Long id) {
        repository.deleteById(id);
    }

    public RepairRequest updateStatus(Long id, String status) {
        RepairRequest request = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("RepairRequest not found with id: " + id));
        request.setStatus(status);
        return repository.save(request);
    }
}
